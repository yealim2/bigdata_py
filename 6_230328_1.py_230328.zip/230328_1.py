import calculator

calculator.addtion(1,2)
calculator.subtraction(1,2)
calculator.multiplication(1,2)
calculator.divition(1,2)
calculator.rest(1,2)
