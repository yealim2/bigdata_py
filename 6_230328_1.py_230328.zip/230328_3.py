import turtle as p

p.color("red")
p.shape("turtle")

p.forward(100)
p.left(90)
p.forward(100)
p.left(90)
p.forward(100)
p.left(90)
p.forward(100)
p.left(90)
