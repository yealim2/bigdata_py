# 모듈 : 사용자가 직접만든 라이브러리
# 모듈: 함수들의 모음
#라이브러리

def addtion (n1,n2):
    print('덧셈연산결과: ',n1 + n2)
    
def subtraction (n1,n2):
    print('뻴셈연산결과: ',n1 - n2)

def multiplication (n1,n2):
    print('곱셈연산결과: ',n1 * n2)

def divition (n1,n2):
    print('나눗셈연산결과: ',n1 / n2)

def rest (n1,n2):
    print('나머지 연산결과: ',n1 % n2)

def portion(n1,n2):
    print('몫 연산결과: ',n1 // n2)
