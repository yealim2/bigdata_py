#계산기 모듈 이름 바꾸기 
import calculator as t

t.addtion(1,2)
t.subtraction(1,2)
t.multiplication(1,2)
t.divition(1,2)
t.rest(1,2)
